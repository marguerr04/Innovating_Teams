
function show(id){
  document.querySelectorAll('.view').forEach(v=>{ v.classList.remove('show'); });
  document.getElementById('view-'+id).classList.add('show');
  document.querySelectorAll('.menu .item[data-view]').forEach(a=>a.classList.remove('active'));
  document.querySelector('.menu .item[data-view=\"'+id+'\"]').classList.add('active');
}
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.menu .item[data-view]').forEach(a => {
    a.addEventListener('click', (e)=>{ e.preventDefault(); show(a.getAttribute('data-view')); });
  });
  show('home');

  const form = document.getElementById('perfil-admin');
  if(form){
    const i = document.getElementById('a-institucion');
    const c = document.getElementById('a-cargo');
    const n = document.getElementById('a-nombre');
    const e = document.getElementById('a-email');
    const t = document.getElementById('a-telefono');
    const cancel = document.getElementById('a-cancelar');

    const saved = JSON.parse(localStorage.getItem('perfilAdmin')||'{}');
    i.value = saved.institucion || '';
    c.value = saved.cargo || '';
    n.value = saved.nombre || '';
    e.value = saved.email || '';
    t.value = saved.telefono || '';

    cancel.addEventListener('click', ()=>{
      i.value = saved.institucion || '';
      c.value = saved.cargo || '';
      n.value = saved.nombre || '';
      e.value = saved.email || '';
      t.value = saved.telefono || '';
    });

    form.addEventListener('submit', (ev)=>{
      ev.preventDefault();
      if(e.value && !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(e.value)){ alert('Correo inválido'); return; }
      localStorage.setItem('perfilAdmin', JSON.stringify({
        institucion: i.value.trim(),
        cargo: c.value.trim(),
        nombre: n.value.trim(),
        email: e.value.trim(),
        telefono: t.value.trim()
      }));
      alert('Perfil de administrador guardado');
      show('home');
    });
  }
});
