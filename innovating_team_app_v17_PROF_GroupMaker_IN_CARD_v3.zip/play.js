
function qs(k){ return new URLSearchParams(location.search).get(k) || ''; }

function getGames(){ try{return JSON.parse(localStorage.getItem('juegos')||'[]')}catch{return []} }
function setGames(v){ localStorage.setItem('juegos', JSON.stringify(v)); }
function useRT(){ return window.RT && RT.isEnabled(); }

function saveGames(a){ localStorage.setItem('juegos', JSON.stringify(a)); }
function findGameByPin(pin){ return getGames().find(g => String(g.pin)===String(pin)); }
function fmt(ms){ const s=Math.max(0,Math.floor(ms/1000)); const m = String(Math.floor(s/60)).padStart(2,'0'); const ss = String(s%60).padStart(2,'0'); return m+':'+ss; }


function soundEngine(){
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  function beep(freq=880, dur=0.15, type='sine', gain=0.05){
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type; osc.frequency.value = freq;
    g.gain.value = gain;
    osc.connect(g); g.connect(ctx.destination);
    osc.start();
    setTimeout(()=>{ g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime+0.04); osc.stop(ctx.currentTime+0.05); }, Math.max(10, dur*1000));
  }
  return {
    found(){ beep(880,0.1,'triangle',0.08); setTimeout(()=>beep(1175,0.08,'triangle',0.08), 90); },
    end(){ beep(440,0.25,'sawtooth',0.06); setTimeout(()=>beep(330,0.25,'sawtooth',0.06), 260); setTimeout(()=>beep(262,0.35,'sawtooth',0.06), 560); },
    tick(){ beep(1000,0.08,'square',0.04); }
  };
}

function mountSopa(container){
  const WORDS = ["UDD","TOKEN","GRUPO","JUEGO","INNOVA"];
  const N=12;
  const grid = Array.from({length:N}, ()=>Array.from({length:N}, ()=>null));
  const DIRS = [
    [0,1],[1,0],[0,-1],[-1,0], // H, V
    [1,1],[1,-1],[-1,1],[-1,-1] // diagonales
  ];

  function canPlace(w, r, c, dr, dc){
    for(let i=0;i<w.length;i++){
      const rr=r+i*dr, cc=c+i*dc;
      if(rr<0||rr>=N||cc<0||cc>=N) return false;
      const ch = grid[rr][cc];
      if(ch!==null && ch!==w[i]) return false;
    }
    return true;
  }
  function placeWord(w){
    // intenta al derecho o al revés
    const variants=[w, w.split('').reverse().join('')];
    for(let attempt=0; attempt<400; attempt++){
      const ww = variants[Math.floor(Math.random()*variants.length)];
      const [dr,dc] = DIRS[Math.floor(Math.random()*DIRS.length)];
      const r = Math.floor(Math.random()*N);
      const c = Math.floor(Math.random()*N);
      if(canPlace(ww,r,c,dr,dc)){
        for(let i=0;i<ww.length;i++){
          const rr=r+i*dr, cc=c+i*dc;
          grid[rr][cc]=ww[i];
        }
        return true;
      }
    }
    return false;
  }
  // place all words; if fail, regenerate grid
  let ok=false;
  for(let attempts=0; attempts<50 && !ok; attempts++){
    for(let r=0;r<N;r++) for(let c=0;c<N;c++) grid[r][c]=null;
    ok = WORDS.every(w => placeWord(w));
  }
  if(!ok){
    console.warn("No se pudo generar la sopa en intentos máximos; usando fallback simple");
    // fallback: horizontal simple
    for(let r=0;r<WORDS.length;r++){
      for(let i=0;i<WORDS[r].length;i++) grid[r][i]=WORDS[r][i];
    }
  }
  // rellenar celdas vacías con letras aleatorias
  for(let r=0;r<N;r++) for(let c=0;c<N;c++) if(grid[r][c]===null) grid[r][c]=String.fromCharCode(65+Math.floor(Math.random()*26));

  const SND = soundEngine();

  const found = new Set();
  const ui = document.createElement('div'); ui.className='grid-game';
  const board = document.createElement('div'); board.className='board';
  board.style.gridTemplateColumns = `repeat(${N}, 32px)`;

  const cells = [];
  for(let r=0;r<N;r++){
    cells[r]=[];
    for(let c=0;c<N;c++){
      const cell=document.createElement('div'); cell.className='cell'; cell.textContent=grid[r][c];
      cell.dataset.r=r; cell.dataset.c=c;
      cells[r][c]=cell; board.appendChild(cell);
    }
  }

  const right = document.createElement('div');
  right.innerHTML = '<h3>Palabras</h3><ul class="word-list">'+WORDS.map(w=>`<li data-w="${w}">${w}</li>`).join('')+'</ul>';
  const listEl = right.querySelector('.word-list');

  // selección por arrastre
  let dragging=false, start=null, lastPreview=[];
  function sameLine(r1,c1,r2,c2){
    const dr = Math.sign(r2-r1), dc = Math.sign(c2-c1);
    if(dr===0 && dc===0) return null;
    // debe ser línea recta: horizontal, vertical o diagonal perfecta
    if(r1!==r2 && c1!==c2 && Math.abs(r2-r1)!==Math.abs(c2-c1)) return null;
    return [dr,dc];
  }
  function clearPreview(){
    lastPreview.forEach(([rr,cc])=> cells[rr][cc].classList.remove('sel'));
    lastPreview=[];
  }
  function previewLine(r1,c1,r2,c2){
    clearPreview();
    const dir = sameLine(r1,c1,r2,c2);
    if(!dir) return;
    const [dr,dc]=dir;
    let rr=r1, cc=c1;
    while(true){
      lastPreview.push([rr,cc]);
      cells[rr][cc].classList.add('sel');
      if(rr===r2 && cc===c2) break;
      rr+=dr; cc+=dc;
    }
  }
  function collectString(path){
    return path.map(([rr,cc])=>grid[rr][cc]).join('');
  }
  function tryValidate(path){
    if(path.length<2) return false;
    const s = collectString(path);
    const srev = s.split('').reverse().join('');
    const match = WORDS.find(w => w===s || w===srev);
    if(match && !found.has(match)){
      found.add(match);
      listEl.querySelector(`li[data-w="${match}"]`).classList.add('found');
      // marcar permanente
      path.forEach(([rr,cc])=> cells[rr][cc].classList.add('sel-perm'));
      SND.found();
      // ¿terminó?
      if(found.size===WORDS.length){
        SND.end();
      }
      return true;
    }
    return false;
  }

  board.addEventListener('mousedown', (e)=>{
    const t=e.target.closest('.cell'); if(!t) return;
    dragging=true;
    start=[+t.dataset.r, +t.dataset.c];
    previewLine(start[0], start[1], start[0], start[1]);
  });
  board.addEventListener('mousemove', (e)=>{
    if(!dragging) return;
    const t=e.target.closest('.cell'); if(!t) return;
    const r=+t.dataset.r, c=+t.dataset.c;
    previewLine(start[0], start[1], r, c);
  });
  window.addEventListener('mouseup', ()=>{
    if(!dragging) return;
    dragging=false;
    const ok = tryValidate(lastPreview);
    clearPreview();
  });

  // soporte touch
  board.addEventListener('touchstart',(e)=>{
    const t=e.target.closest('.cell'); if(!t) return;
    dragging=true; const r=+t.dataset.r, c=+t.dataset.c;
    start=[r,c]; previewLine(r,c,r,c);
  }, {passive:true});
  board.addEventListener('touchmove',(e)=>{
    if(!dragging) return;
    const touch=e.touches[0];
    const el=document.elementFromPoint(touch.clientX, touch.clientY);
    const t=el && el.closest ? el.closest('.cell') : null;
    if(!t) return;
    const r=+t.dataset.r, c=+t.dataset.c;
    previewLine(start[0], start[1], r, c);
  }, {passive:true});
  window.addEventListener('touchend', ()=>{
    if(!dragging) return; dragging=false; const ok=tryValidate(lastPreview); clearPreview();
  });

  const left = document.createElement('div'); left.appendChild(board);
  ui.appendChild(left); ui.appendChild(right); container.appendChild(ui);
}

  });
  const sel=[]; const found=new Set();
  const board=document.createElement('div'); board.className='board';
  for(let r=0;r<N;r++){
    for(let c=0;c<N;c++){
      const cell=document.createElement('div'); cell.className='cell'; cell.textContent=grid[r][c];
      cell.onclick=()=>{
        const k=r+'-'+c; const active=cell.classList.toggle('sel');
        if(active) sel.push({r,c,letter:grid[r][c]}); else { const i=sel.findIndex(x=>x.r===r&&x.c===c); if(i>=0) sel.splice(i,1); }
      };
      board.appendChild(cell);
    }
  }
  const ui=document.createElement('div'); ui.className='grid-game';
  const left=document.createElement('div'); left.appendChild(board);
  const right=document.createElement('div');
  right.innerHTML='<h3>Palabras</h3><ul class="word-list">'+WORDS.map(w=>`<li data-w="${w}">${w}</li>`).join('')+'</ul><button id="check" class="btn btn-orange" style="margin-top:10px">Validar selección</button>';
  ui.appendChild(left); ui.appendChild(right); container.appendChild(ui);
  function strings(){
    const byRow=sel.slice().sort((a,b)=> a.r===b.r ? a.c-b.c : a.r-b.r).map(x=>x.letter).join('');
    const byCol=sel.slice().sort((a,b)=> a.c===b.c ? a.r-b.r : a.c-b.c).map(x=>x.letter).join('');
    return [byRow, byCol];
  }
  right.querySelector('#check').onclick=()=>{
    const [s1,s2]=strings();
    const match=["UDD","TOKEN","GRUPO","JUEGO","INNOVA"].find(w=>w===s1||w===s2);
    if(match && !found.has(match)){
      found.add(match); right.querySelector(`li[data-w="${match}"]`).classList.add('found');
      document.querySelectorAll('.cell.sel').forEach(e=>e.classList.remove('sel')); sel.length=0;
      alert('¡Encontraste '+match+'!');
    } else { alert('No coincide. Selecciona letras contiguas en línea recta.'); }
  };
}
function mountPalabras(container){
  const TARGETS=["EQUIPO","IDEA","TOKEN","GRUPO","UDD"];
  const letters=Array.from(new Set(TARGETS.join('').split('')));
  const pool=letters.concat(letters).sort(()=>Math.random()-.5);
  const wrap=document.createElement('div'); wrap.innerHTML='<h3>Forma palabras con las letras</h3>';
  const area=document.createElement('div'); area.className='scramble';
  pool.forEach(ch=>{ const chip=document.createElement('div'); chip.className='chip'; chip.textContent=ch; chip.onclick=()=>{ if(chip.classList.contains('used')) return; chip.classList.add('used'); input.value+=ch; }; area.appendChild(chip); });
  const input=document.createElement('input'); input.className='input'; input.placeholder='Escribe o arma tu palabra';
  const add=document.createElement('button'); add.textContent='Agregar'; add.className='btn btn-orange'; add.style.marginTop='6px';
  const list=document.createElement('ul'); list.className='answers'; const found=new Set();
  add.onclick=()=>{ const w=input.value.toUpperCase().trim(); if(!w) return;
    if(TARGETS.includes(w) && !found.has(w)){ found.add(w); const li=document.createElement('li'); li.textContent=w; list.appendChild(li); }
    input.value=''; document.querySelectorAll('.chip.used').forEach(e=>e.classList.remove('used')); };
  wrap.appendChild(area); wrap.appendChild(input); wrap.appendChild(add); wrap.appendChild(list); container.appendChild(wrap);
}
function mountHielo(container){
  const qs = ["¿Cuál fue tu mayor logro reciente?","¿Qué te motiva a emprender?","Cuenta una anécdota divertida de clases."];
  const div=document.createElement('div'); div.className='ice';
  div.innerHTML='<h3>Rompehielo</h3><p>'+qs[Math.floor(Math.random()*qs.length)]+'</p><p class="muted">Conversen en su grupo durante el tiempo.</p>';
  container.appendChild(div);
}

document.addEventListener('DOMContentLoaded', ()=>{
  const pin = qs('pin'); if(!pin){ location.href='index.html'; return; }
  let game = findGameByPin(pin); if(!game){ alert('Partida no encontrada'); location.href='index.html'; return; }
  if(!game.selectedActivity){ location.href='waiting-room.html?pin='+pin; return; }
  document.getElementById('activity').textContent=game.selectedActivity;
  const status=document.getElementById('status'); const timer=document.getElementById('timer'); const area=document.getElementById('game-area');
  const tickAudio=document.getElementById('tick');

  // ---------- Montaje robusto de la actividad ----------
  function mountActivity(name){
    try{
      if(/sopa/i.test(name)) { mountSopa(area); return; }
      if(/palabra/i.test(name)) { mountPalabras(area); return; }
      if(/hielo|rompe/i.test(name)) { mountHielo(area); return; }
      // fallback
      const p = document.createElement('p');
      p.textContent = 'No se reconoce la actividad "'+name+'".';
      area.appendChild(p);
    }catch(err){
      console.error('Error montando actividad', err);
      const pre = document.createElement('pre');
      pre.textContent = 'Error montando la actividad: '+err.message;
      pre.style.background = '#fee'; pre.style.color = '#900'; pre.style.padding='10px'; pre.style.borderRadius='8px';
      area.appendChild(pre);
    }
  }

// Try to unmute if permission was primed earlier
if(localStorage.getItem('audioUnlocked')==='1'){ try{ tickAudio.muted=false; tickAudio.volume=1.0; tickAudio.currentTime=0; const p=tickAudio.play(); if(p) p.then(()=>tickAudio.pause()).catch(()=>{});}catch(e){} }
// As a fallback, capture first gesture here too
window.addEventListener('pointerdown', ()=>{ try{ tickAudio.muted=false; tickAudio.volume=1.0; tickAudio.currentTime=0; const p=tickAudio.play(); if(p) p.then(()=>tickAudio.pause()).catch(()=>{});}catch(e){} }, { once:true });
  // Controles de audio
  const testBtn = document.getElementById('test-audio');
  const muteChk = document.getElementById('mute-audio');
  if(testBtn){
    testBtn.addEventListener('click', ()=>{
      try{ tickAudio.currentTime = 0; tickAudio.play(); }catch(e){}
    });
  }
  if(muteChk){
    muteChk.addEventListener('change', ()=>{
      if(muteChk.checked){ tickAudio.muted = true; } else { tickAudio.muted = false; }
    });
  }

  mountActivity(game.selectedActivity);
  function fmt(ms){ const s=Math.max(0,Math.floor(ms/1000)); const m=String(Math.floor(s/60)).padStart(2,'0'); const ss=String(s%60).padStart(2,'0'); return m+':'+ss; }
  const modeSel=document.getElementById('sound-mode');
  // persist and load mode
  const savedMode = localStorage.getItem('soundMode')||'last10'; if(modeSel) modeSel.value=savedMode;
  modeSel && modeSel.addEventListener('change', ()=> localStorage.setItem('soundMode', modeSel.value));
  function playBeep(){ try{ if(!tickAudio.paused) tickAudio.currentTime=0; const p=tickAudio.play(); if(p) p.then(()=>{ setTimeout(()=>{ try{ tickAudio.pause(); }catch(e){} }, 250); }).catch(()=>{});}catch(e){} }
  function tick(){ if(useRT()){ /* game sync vendrá por RT listener */ } else { game=findGameByPin(pin)||game; } const ms=(game.playEndAt||0)-Date.now(); timer.textContent=fmt(ms); status.textContent= ms>0 ? 'En curso' : 'Tiempo finalizado';
    const mode = (modeSel && modeSel.value) || 'last10';
    if(mode!=='mute' && (!muteChk || !muteChk.checked)){
      if(mode==='every' && ms>0){ playBeep(); }
      if(mode==='last10' && ms<=10000 && ms>0){ playBeep(); }
    }
    if(ms>0){ if(muteChk && muteChk.checked){} else { try{ if(!tickAudio.paused) tickAudio.currentTime=0; tickAudio.play().then(()=>{ /* stop quickly to avoid overlap */ setTimeout(()=>{ try{ tickAudio.pause(); }catch(e){} }, 250); }).catch(()=>{}); } catch(e){} } }
    if(ms<=0){ game.status='phase2'; saveGames(getGames().map(x=>x.id===game.id?game:x)); clearInterval(intv); setTimeout(()=>alert('Tiempo terminado. Siguiente fase próximamente.'),200); } }
  if(useRT()){ try{ RT.init(); RT.on(pin, data=>{ if(!data) return; game=data; setGames((getGames().map(x=>x.id===game.id?game:x))); }); }catch(e){} }
  tick(); const intv=setInterval(tick,1000);
});
