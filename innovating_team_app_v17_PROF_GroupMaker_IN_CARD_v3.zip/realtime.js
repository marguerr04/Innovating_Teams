// realtime.js — Abstracción de tiempo real (Firebase) con fallback localStorage
(function(){
  window.RT = {
    isEnabled(){
      return localStorage.getItem('realtime') === 'on' && !!window.firebase && !!window.firebase.database;
    },
    init(){
      if(!this.isEnabled()) return;
      if(!window._rt_init){
        try{
          if(!window.firebase.apps || !window.firebase.apps.length){
            // La configuración se inyecta desde firebase-config.js (window.firebaseConfig)
            if(!window.firebaseConfig){ console.warn('Falta firebaseConfig'); return; }
            firebase.initializeApp(window.firebaseConfig);
          }
          window._rt_init = true;
        }catch(e){ console.error(e); }
      }
    },
    ref(pin){ return firebase.database().ref('games/'+pin); },
    get(pin){ return this.ref(pin).get().then(s=>s.val()); },
    set(pin, data){ return this.ref(pin).set(data); },
    on(pin, cb){ this.ref(pin).on('value', snap => cb(snap.val())); },
    off(pin){ this.ref(pin).off(); }
  };
})();