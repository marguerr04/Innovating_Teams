// Copia firebase-config.example.js a este archivo y rellena tu configuración.
