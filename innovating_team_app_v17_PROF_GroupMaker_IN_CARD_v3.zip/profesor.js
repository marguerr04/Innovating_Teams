
// Catálogos
const MAX_INTEGRANTES=10, MAX_GRUPOS=4, MAX_ANIO=7;
const UNIVERSIDADES_CL = [
  "Universidad de Chile","Pontificia Universidad Católica de Chile","Universidad de Santiago de Chile",
  "Universidad de Concepción","Universidad Técnica Federico Santa María","Pontificia Universidad Católica de Valparaíso",
  "Universidad de Valparaíso","Universidad Austral de Chile","Universidad de Talca","Universidad de La Serena",
  "Universidad Católica del Norte","Universidad de Antofagasta","Universidad de Tarapacá","Universidad de Atacama",
  "Universidad de Magallanes","Universidad del Bío‑Bío","Universidad de La Frontera","Universidad de O’Higgins",
  "Universidad de Aysén","Universidad Diego Portales","Universidad Adolfo Ibáñez","Universidad Alberto Hurtado",
  "Universidad Andrés Bello","Universidad del Desarrollo","Universidad Mayor","Universidad Finis Terrae",
  "Universidad San Sebastián","Universidad Católica Silva Henríquez","Universidad Santo Tomás","Universidad de Las Américas"
].sort();
const CARRERAS_BASE = [
  "Ingeniería Civil Informática","Ingeniería Comercial","Ingeniería Industrial","Medicina","Enfermería","Odontología",
  "Kinesiología","Nutrición y Dietética","Psicología","Derecho","Arquitectura","Diseño","Periodismo","Publicidad",
  "Administración Pública","Trabajo Social","Pedagogía en Educación Básica","Pedagogía en Educación Parvularia",
  "Fonoaudiología","Tecnología Médica","Bioquímica","Química y Farmacia","Construcción Civil","Ingeniería Mecánica",
  "Ingeniería Electrónica","Ingeniería Civil","Data Science","Matemática","Física","Otra (especificar)"
].sort();

function opt(elm, v, t){ const o=document.createElement('option'); o.value=v; o.textContent=t||v; elm.appendChild(o); }
function show(id){
  document.querySelectorAll('.view').forEach(v=>{ v.classList.remove('show'); });
  document.getElementById('view-'+id).classList.add('show');
  document.querySelectorAll('.menu .item[data-view]').forEach(a=>a.classList.remove('active'));
  document.querySelector('.menu .item[data-view=\"'+id+'\"]').classList.add('active');
}

document.addEventListener('DOMContentLoaded', () => {

// ---- Prime/Unlock audio once per session ----
function primeAudioOnce(){
  if(localStorage.getItem('audioUnlocked')==='1') return;
  try{
    const a = new Audio('assets/cronometro.mp3');
    a.volume = 0.0;
    const p = a.play();
    if(p && typeof p.then==='function'){
      p.then(()=>{ a.pause(); localStorage.setItem('audioUnlocked','1'); }).catch(()=>{});
    }
  }catch(e){}
}
// Call on first user gesture if needed
window.addEventListener('pointerdown', ()=>primeAudioOnce(), { once:true });

  // Navegación
  document.querySelectorAll('.menu .item[data-view]').forEach(a => {
    a.addEventListener('click', (e)=>{ e.preventDefault(); show(a.getAttribute('data-view')); });
  });
  show('home'); // Menú principal primero

  // Crear juego
  const form = document.getElementById('crear-juego');
  if(form){
    const $i = document.getElementById('integrantes');
    const $g = document.getElementById('grupos');
    const $a = document.getElementById('anio');
    const $u = document.getElementById('universidad');
    const $c = document.getElementById('carrera');
    const $otra = document.getElementById('carrera-otra');
    const $crear = document.getElementById('crear');
    const $cancelar = document.getElementById('cancelar');

    opt($i,'','Selecciona (1–10)'); $i.firstChild.disabled=true; $i.firstChild.selected=true;
    opt($g,'','Selecciona (1–4)');  $g.firstChild.disabled=true; $g.firstChild.selected=true;
    opt($a,'','Selecciona (1–7)');  $a.firstChild.disabled=true; $a.firstChild.selected=true;
    opt($u,'','Selecciona universidad (Chile)'); $u.firstChild.disabled=true; $u.firstChild.selected=true;
    opt($c,'','Selecciona carrera'); $c.firstChild.disabled=true; $c.firstChild.selected=true;

    for(let n=1;n<=MAX_INTEGRANTES;n++) opt($i,n);
    for(let n=1;n<=MAX_GRUPOS;n++) opt($g,n);
    for(let n=1;n<=MAX_ANIO;n++) opt($a,n);
    UNIVERSIDADES_CL.forEach(u=>opt($u,u));
    CARRERAS_BASE.forEach(c=>opt($c,c));

    function validate(){
      const ok = $i.value && $g.value && $a.value && $u.value && $c.value &&
                ($c.value!=='Otra (especificar)' || $otra.value.trim().length>1);
      $crear.disabled = !ok;
    }
    [$i,$g,$a,$u,$c].forEach(x=>x.addEventListener('change', ()=>{
      if($c.value==='Otra (especificar)') $otra.style.display='block'; else { $otra.style.display='none'; $otra.value=''; }
      validate();
    }));
    $otra.addEventListener('input', validate);
    $cancelar.addEventListener('click', ()=>{ form.reset(); $otra.style.display='none'; validate(); });

    form.addEventListener('submit', (e)=>{ primeAudioOnce();
      e.preventDefault();
      const payload = {
        integrantesMax: parseInt($i.value,10),
        grupos: parseInt($g.value,10),
        anio: parseInt($a.value,10),
        universidad: $u.value,
        carrera: $c.value==='Otra (especificar)' ? $otra.value.trim() : $c.value
      };
      // Generar PIN de 6 dígitos
      const pin = String(Math.floor(100000 + Math.random()*900000));
      const groups = Array.from({length: payload.grupos}, ()=>({ members: [] }));
      const game = { id: Date.now(), pin, ...payload, groups };
      const juegos = JSON.parse(localStorage.getItem('juegos')||'[]');
      juegos.push(game);
      localStorage.setItem('juegos', JSON.stringify(juegos));
      if(window.RT && RT.isEnabled()){ try{ RT.set(pin, game); }catch(e){} }
      alert('Juego creado con éxito.\nPIN: '+pin);
      window.open('waiting-room.html?pin='+pin+'&role=prof', '_blank');
      show('home');
    });
  }


    // --- listado de últimos juegos ---
    const home = document.getElementById('view-home');
    if(home){
      const list = document.createElement('div');
      list.className = 'card';
      list.style.marginTop = '14px';
      const juegos = JSON.parse(localStorage.getItem('juegos')||'[]').slice(-5).reverse();
      list.innerHTML = '<h3 class="title" style="margin:0 0 10px">Juegos recientes</h3>' + (juegos.length? '<ul style="margin-left:18px">' + juegos.map(j=>`<li>PIN <b>${j.pin}</b> · ${j.grupos} grupos · max ${j.integrantesMax} / grupo <a style="margin-left:8px" href="waiting-room.html?pin=${j.pin}" target="_blank">Ver sala</a></li>`).join('') + '</ul>' : '<p class="muted">Aún no has creado juegos.</p>');
      home.appendChild(list);
    }



  // Realtime toggle
  const rt = document.getElementById('rt-toggle');
  if(rt){ rt.checked = (localStorage.getItem('realtime')==='on'); rt.addEventListener('change', ()=>{ localStorage.setItem('realtime', rt.checked?'on':'off'); if(window.RT){ RT.init(); } }); }
  if(window.RT){ RT.init(); }

  // Botón 'Iniciar votación del último PIN'
  const startLatest = document.getElementById('start-latest');
  if(startLatest){
    startLatest.addEventListener('click', ()=>{ primeAudioOnce();
      const all = JSON.parse(localStorage.getItem('juegos')||'[]');
      if(!all.length){ alert('Primero crea un juego.'); location.hash = '#/crear'; return; }
      const game = all[all.length-1];
      game.status = 'choosing';
      game.chooseDeadline = Date.now() + 45*1000;
      localStorage.setItem('juegos', JSON.stringify(all.map(x=>x.id===game.id?game:x)));
      window.open('waiting-room.html?pin='+game.pin+'&role=prof','_blank');
    });
  }

  // Editar perfil

  const pForm = document.getElementById('perfil-form');
  if(pForm){
    const institucion = document.getElementById('perfil-institucion');
    const carrera = document.getElementById('perfil-carrera');
    const nombre = document.getElementById('perfil-nombre');
    const email = document.getElementById('perfil-email');
    const tel = document.getElementById('perfil-telefono');
    const cancel = document.getElementById('perfil-cancelar');

    const saved = JSON.parse(localStorage.getItem('perfilProfesor')||'{}');
    institucion.value = saved.institucion || '';
    carrera.value = saved.carrera || '';
    nombre.value = saved.nombre || '';
    email.value = saved.email || '';
    tel.value = saved.telefono || '';

    cancel.addEventListener('click', ()=>{
      institucion.value = saved.institucion || '';
      carrera.value = saved.carrera || '';
      nombre.value = saved.nombre || '';
      email.value = saved.email || '';
      tel.value = saved.telefono || '';
    });

    pForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      if(email.value && !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email.value)){ alert('Correo inválido'); return; }
      localStorage.setItem('perfilProfesor', JSON.stringify({
        institucion: institucion.value.trim(),
        carrera: carrera.value.trim(),
        nombre: nombre.value.trim(),
        email: email.value.trim(),
        telefono: tel.value.trim()
      }));
      alert('Perfil guardado');
      show('home');
    });
  }
});
