
function qs(k){ return new URLSearchParams(location.search).get(k) || ''; }

function getGames(){ try{return JSON.parse(localStorage.getItem('juegos')||'[]')}catch{return []} }
function setGames(v){ localStorage.setItem('juegos', JSON.stringify(v)); }
function useRT(){ return window.RT && RT.isEnabled(); }

function saveGames(arr){ setGames(arr); const pin = qs('pin'); if(useRT()){ try{ const g = arr.find(x=>String(x.pin)===String(pin)); if(g) RT.set(pin,g);}catch(e){} } }
function findGameByPin(pin){ return getGames().find(g => String(g.pin)===String(pin)); }

function qsp(k){ return new URLSearchParams(location.search).get(k) || ''; }
function isProfessor(){ return qsp('role')==='prof'; }

// ---- Prime/Unlock audio once per session ----
function primeAudioOnce(){
  if(localStorage.getItem('audioUnlocked')==='1') return;
  try{
    const a = new Audio('assets/cronometro.mp3');
    a.volume = 0.0;
    const p = a.play();
    if(p && typeof p.then==='function'){
      p.then(()=>{ a.pause(); localStorage.setItem('audioUnlocked','1'); }).catch(()=>{});
    }
  }catch(e){}
}
// Call on first user gesture if needed
window.addEventListener('pointerdown', ()=>primeAudioOnce(), { once:true });

const ACTIVITIES = ["Sopa de letras","Armar palabras con letras","Romper el hielo con el grupo"];
function ensureVotes(game){
  if(!game.votes) game.votes={};
  if(!game.voteCounts) game.voteCounts={};
  ACTIVITIES.forEach(a=>{ if(!(a in game.voteCounts)) game.voteCounts[a]=0; });
}
function renderVote(game){
  const box = document.getElementById('vote'); if(!box) return;
  const form = document.getElementById('vote-form');
  const stats = document.getElementById('vote-stats');
  const timer = document.getElementById('vote-timer');
  const btn = document.getElementById('vote-submit');
  const chooseBtn = document.getElementById('choose-skip');

  if(game.status!=='choosing'){ box.style.display='none'; return; }
  box.style.display='block';
  form.innerHTML = ACTIVITIES.map((a,i)=>`<label style="display:flex;align-items:center;gap:10px;margin:8px 0">
    <input type="radio" name="activity" value="${a}" ${i===0?'checked':''}/> ${a}</label>`).join('');
  ensureVotes(game);
  function tick(){
    const ms = Math.max(0,(game.chooseDeadline||0)-Date.now());
    timer.textContent = 'Tiempo para elegir: '+Math.ceil(ms/1000)+'s';
    if(isProfessor()){
      stats.style.display='block';
      stats.textContent='Votos: '+ACTIVITIES.map(a=>`${a}: ${game.voteCounts[a]||0}`).join(' · ');
      chooseBtn.style.display='inline-block';
    } else { stats.style.display='none'; chooseBtn.style.display='none'; }
    // auto-cierre si todos votaron
    const total = game.groups.reduce((a,g)=>a+g.members.length,0);
    const rec = Object.keys(game.votes).length;
    if(total>0 && rec>=total){
      let winner=ACTIVITIES[0], best=-1;
      ACTIVITIES.forEach(a=>{ const c=game.voteCounts[a]||0; if(c>best){best=c; winner=a;} });
      game.selectedActivity=winner; game.status='playing'; game.playEndAt=Date.now()+5*60*1000;
      const all=getGames().map(x=>x.id===game.id?game:x); saveGames(all);
      location.href='play.html?pin='+game.pin; return;
    }
    if(ms<=0){
      if(!game.selectedActivity){
        let winner=ACTIVITIES[0], best=-1;
        ACTIVITIES.forEach(a=>{ const c=game.voteCounts[a]||0; if(c>best){best=c; winner=a;} });
        game.selectedActivity=winner; game.status='playing'; game.playEndAt=Date.now()+5*60*1000;
        const all=getGames().map(x=>x.id===game.id?game:x); saveGames(all);
        location.href='play.html?pin='+game.pin; return;
      }
    }
  }
  tick();
  clearInterval(window._vt); window._vt=setInterval(()=>{ const latest=findGameByPin(game.pin)||game; game=latest; tick(); },1000);
  btn.onclick=(e)=>{ e.preventDefault(); primeAudioOnce();
    const rut=qsp('rut'); const choice=(new FormData(form)).get('activity'); if(!rut) return alert('Abre desde Alumno para votar');
    if(game.votes[rut]) return alert('Ya votaste');
    game.votes[rut]=choice; game.voteCounts[choice]=(game.voteCounts[choice]||0)+1;
    saveGames(getGames().map(x=>x.id===game.id?game:x));
  };
  chooseBtn.onclick=(e)=>{ e.preventDefault(); primeAudioOnce(); if(!isProfessor()) return;
    const choice=form.querySelector('input[name="activity"]:checked').value;
    game.selectedActivity=choice; game.status='playing'; game.playEndAt=Date.now()+5*60*1000;
    saveGames(getGames().map(x=>x.id===game.id?game:x)); location.href='play.html?pin='+game.pin;
  };
}

function renderProfActions(game){
  const box = document.getElementById('prof-actions');
  if(!box) return;
  if(isProfessor() && game.status!=='choosing' && game.status!=='playing'){
    box.style.display='block';
    const btn = document.getElementById('force-start');
    btn.onclick = ()=>{
      game.status='choosing';
      game.chooseDeadline = Date.now() + 45*1000;
      saveGames(getGames().map(x=>x.id===game.id?game:x));
      render(game);
    };
  } else {
    box.style.display='none';
  }
}

function renderRename(game){
  const nick=qsp('nick'); const rut=qsp('rut');
  const idx = game.groups.findIndex(g=>g.members.some(m=>m.rut===rut));
  const wrap=document.getElementById('groups'); if(idx<0) return;
  const card = wrap.children[idx]; const current = game.groups[idx].name || ('Grupo '+(idx+1));
  const box = document.createElement('div'); box.style.marginTop='8px';
  box.innerHTML='<input id="gname" class="input" placeholder="Nombre del grupo" value="'+current+'"/>'+
                '<button id="saveName" class="btn btn-teal" style="margin-top:6px">💾 Guardar nombre del grupo</button>';
  card.appendChild(box);
  card.querySelector('#saveName').onclick=()=>{
    const val = card.querySelector('#gname').value.trim(); if(!val) return;
    game.groups[idx].name=val; saveGames(getGames().map(x=>x.id===game.id?game:x)); render(game);
  };
}

function render(game){
  document.getElementById('pin').textContent = game.pin;
  const wrap = document.getElementById('groups');
  wrap.innerHTML='';
  game.groups.forEach((gr,i)=>{
    const li = document.createElement('div');
    li.className='group';
    const gname = gr.name || ('Grupo '+(i+1));
    li.innerHTML = `<h3>${gname} <small>(${gr.members.length}/${game.integrantesMax})</small></h3>` +
                   `<ul style="margin:6px 0 0 18px">${gr.members.map(m=>`<li>${m.nick}</li>`).join('') || '<li style="opacity:.6">Vacío</li>'}</ul>`;
    wrap.appendChild(li);
  });
  document.getElementById('footer-note').textContent = `Jugadores totales: ${game.groups.reduce((a,g)=>a+g.members.length,0)}`;
  renderProfActions(game);
  renderVote(game);
  renderRename(game);
}

function joinIfParams(game){
  const nick = qs('nick');
  const rut = qs('rut');
  if(!nick || !rut) return false;
  // ya existe?
  const exists = game.groups.some(g => g.members.some(m => m.rut===rut));
  if(exists) return false;
  // busca grupo con menor tamaño (y con espacio)
  let target = null;
  for(const g of game.groups){
    if(g.members.length < game.integrantesMax){
      if(!target || g.members.length < target.members.length){ target = g; }
    }
  }
  if(!target) return false; // sala llena
  target.members.push({ nick, rut, joinedAt: Date.now() });
  const games = getGames().map(x => x.id===game.id ? game : x);
  saveGames(games);
  // limpiar params en URL para evitar rejoin al recargar
  const url = new URL(location.href); url.searchParams.delete('nick'); url.searchParams.delete('rut'); history.replaceState({}, '', url.toString());
  return true;
}

document.addEventListener('DOMContentLoaded', ()=>{
  const pin = qs('pin');
  if(!pin){ alert('PIN no proporcionado'); location.href='student.html'; return; }
  let game = findGameByPin(pin);
  if(!game){ alert('No existe una sala con ese PIN'); location.href='student.html'; return; }

  // Intentar unirse si vienen parámetros
  joinIfParams(game);
  // Si ya está en juego, redirigir
  if(game.status==='playing'){ location.href='play.html?pin='+pin+'&nick='+qs('nick')+'&rut='+qs('rut'); return; }
  if(useRT()){ try{ RT.init(); RT.on(pin, data => { if(!data) return; // sync local and render
        const all = getGames(); const idx = all.findIndex(x=>String(x.pin)===String(pin)); if(idx>=0) all[idx]=data; else all.push(data); setGames(all);
        render(data); if(data.status==='playing'){ location.href='play.html?pin='+pin+'&nick='+qs('nick')+'&rut='+qs('rut'); }
      }); }catch(e){} }
  render(game);

  // Poll cada 1s para simular tiempo real
  setInterval(()=>{
    const latest = findGameByPin(pin);
    if(latest){ game = latest; render(game); }
  }, 1000);
});
